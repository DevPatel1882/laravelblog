

<?php $__env->startSection('container'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<!-- DataTales Example -->
<div class="container-fluid">
<div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary display-4">Manage Posts</h6>
                            <a href="/admin/user/add" class="btn btn-primary text-light " style="float:right;box-shadow: 10px 10px 10px 0 gray;;">Add new Post</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    
                                    <thead>
                                        <tr>
                                            <th>Sno</th>
                                            <th>name</th>
                                            <th>email</th>
                                            <th>password</th>
                                            <th>status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                       
                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         
                                        <tr>
                                            <td><?php echo e($i->id); ?></td>
                                            <td><?php echo e($i->name); ?></td>
                                            <td><?php echo e($i->email); ?></td>
                                            <td><?php echo e($i->password); ?></td>
                                            <th>
                                            <?php if($i->status==1): ?>    
                                                <a class="btn btn-success" href="/admin/user/status/0/<?php echo e($i->id); ?>" type="button">Active</a>
                                            <?php elseif($i->status==0): ?>
                                                 <a class="btn btn-danger" href="/admin/user/status/1/<?php echo e($i->id); ?>" type="button">Deactive</a>
                                                
                                            <?php endif; ?>
                                            </th>
                                             <td style="width:180px;">
                                                <a class="btn btn-success" href="/admin/user/edit/<?php echo e($i->id); ?>">Edit</a>
                                                <a class="btn btn-danger" href="/admin/user/delete/<?php echo e($i->id); ?>">Delete</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

</div>
<script>let elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
    let switchery = new Switchery(html,  { size: 'small' });
});</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\laravel\blog\resources\views/admin/user/show.blade.php ENDPATH**/ ?>