
<?php $__env->startSection('container'); ?>

<!-- Page Header-->
<header class="masthead" style="background-image: url('assets/img/post-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="post-heading">
                            <h1><?php echo e($result['0']->title); ?></h1>
                            <h2 class="subheading"><?php echo e($result['0']->short_desc); ?></h2>
                            <span class="meta">
                                Posted by
                                <a href="#!"><?php echo e($result['0']->author); ?></a>
                                on <?php echo e($result['0']->post_date); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Post Content-->
        <article class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <p><?php echo e($result['0']->content); ?></p>
                    </div>
                </div>
            </div>
        </article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\laravel\blog\resources\views/front/post.blade.php ENDPATH**/ ?>